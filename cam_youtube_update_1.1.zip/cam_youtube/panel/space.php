<?php
$uploadsDir = 'uploads'; 
$spaceUsed = 0;

if (is_dir($uploadsDir)) {
    $files = scandir($uploadsDir);
    foreach ($files as $file) {
        if ($file !== '.' && $file !== '..') {
            $filePath = $uploadsDir . '/' . $file;
            $spaceUsed += filesize($filePath);
        }
    }
}

$spaceUsedInMB = $spaceUsed / (1024 * 1024);
$spaceUsedFormatted = number_format($spaceUsedInMB, 1); 

header('Content-Type: application/json');
echo json_encode(['spaceUsed' => $spaceUsedFormatted . ' MB']);
?>
