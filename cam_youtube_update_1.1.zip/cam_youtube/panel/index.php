<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="Favicon.ico" type="image/x-icon">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل فایل ها</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: lightblue;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }
        .password-input {
            margin-bottom: 10px;
        }
        .btn {
            margin: 5px;
            padding: 10px 20px;
            font-size: 24px;
            cursor: pointer;
            border-radius: 20px;
        }
        #delete-btn {
            display: none;
            background-color: #FF5733;
            color: #fff;
            border-radius: 20px;
            padding: 10px 20px;
            font-size: 24px;
        }
        #download-link {
            display: none;
            text-decoration: none;
            background-color: #3498db;
            color: #fff;
            border-radius: 20px;
            font-size: 24px;
        }
        #notification {
            display: none;
            margin-top: 10px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>صفحه مدیریت فایل‌ها</h1>
        <form id="password-form">
            <label for="password" class="password-input">لطفاً پسورد را وارد کنید:</label>
            <input type="password" id="password" required>
            <button type="submit" class="btn">ورود</button>
        </form>
        <button id="delete-btn" class="btn">حذف فایل‌ها</button>
        <a id="download-link" class="btn" download>دانلود فایل ZIP</a>
        <p id="space-used"></p>
    </div>
    <script>
        const passwordForm = document.getElementById('password-form');
        const passwordInput = document.getElementById('password');
        const deleteButton = document.getElementById('delete-btn');
        const downloadLink = document.getElementById('download-link');
        const notification = document.getElementById('notification');
        const spaceUsed = document.getElementById('space-used');
        
        const correctPassword = '1234';

        // تابع برای نمایش فضای استفاده شده
        function showSpaceUsed() {
            fetch('space.php', {
                method: 'GET'
            })
            .then(response => response.text())
            .then(data => {
                spaceUsed.textContent = data;
            });
        }

        // نمایش فضای استفاده شده از ابتدا
        showSpaceUsed();

        passwordForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const enteredPassword = passwordInput.value;
            if (enteredPassword === correctPassword) {
                // نمایش دکمه حذف و دانلود
                deleteButton.style.display = 'block';
                downloadLink.style.display = 'block';
                notification.style.display = 'none';
                spaceUsed.style.display = 'block';
                passwordForm.style.display = 'none';
            } else {
                alert('پسورد اشتباه است. دوباره امتحان کنید.');
            }
        });

        deleteButton.addEventListener('click', function() {
            if (confirm('آیا مطمئن هستید که می‌خواهید تمام فایل‌ها را حذف کنید?')) {
                fetch('delete.php', {
                    method: 'POST',
                    body: JSON.stringify({ password: passwordInput.value }),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (response.ok) {
                        alert('فایل‌ها با موفقیت حذف شدند.');
                    } else {
                        alert('خطا در حذف فایل‌ها.');
                    }
                });
            }
        });

        downloadLink.href = 'download.php?password=' + encodeURIComponent(correctPassword);
    </script>
</body>
</html>
