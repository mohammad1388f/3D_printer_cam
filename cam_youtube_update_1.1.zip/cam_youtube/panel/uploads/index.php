<html>
    <head>
        <title>get out !</title>
        <style>
            f1{
                font-size: 100pt;
            }
        </style>
    </head>
    <body>
        <f1>get out of this page!</f1>
        
    </body>
    
    </html>