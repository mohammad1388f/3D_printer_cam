<?php
$correctPassword = '1234';
$enteredPassword = $_GET['password']; // پسورد از پارامتر URL
if ($enteredPassword !== $correctPassword) {
    http_response_code(403);
    exit('Access Denied');
}
$zip = new ZipArchive();
$zipFileName = 'downloaded_files.zip';
if ($zip->open($zipFileName, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
    $directory = 'uploads';
    $files = glob($directory . '/*.jpg');
    foreach ($files as $file) {
        if (is_file($file)) {
            $zip->addFile($file, basename($file));
        }
    }
    $zip->close();
    
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
    readfile($zipFileName);
    unlink($zipFileName);
} else {
    echo 'خطا در ایجاد فایل ZIP';
}
