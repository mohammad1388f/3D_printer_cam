<?php
$target_dir = "panel/uploads/";
if (!empty($_FILES['imageFile'])) {
    $file_name = $_FILES['imageFile']['name'];
    $file_tmp = $_FILES['imageFile']['tmp_name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if ($file_ext == "jpg") { // چک کردن پسوند فایل
        $target_file = $target_dir . date('Y.m.d.H:i:s') . "mohammad_avr_code.jpg";
        if (move_uploaded_file($file_tmp, $target_file)) {
            echo "ok";
        }
    }
}
?>

<html>
<head>
    <title>پنل تصاویر</title>
    <style>
        body {
            background: lightblue;
        }
        .moh_avr div {
            width: 30%;
            display: inline-block;
            background: linear-gradient(225deg, #FF1493, #00FF00, #222);
            margin: 10px;
            padding-top: 10px;
            padding-bottom: 10px;
            border-radius: 50px;
            box-shadow: 0px 0px 30px #555;
        }
        .moh_avr img {
            width: 90%;
            border-radius: 50px;
        }
        h2 {
            width: 70%;
            background: linear-gradient(90deg, #FF1493, #00FF00);
            margin: 10px;
            border-radius: 50px;
            box-shadow: 0px 0px 30px #00FF00;
            color: white;
            font-size: 25pt;
            direction: rtl;
        }
    </style>
</head>
<link rel="icon" href="Favicon.ico" type="image/x-icon">

<body>
<center>
    <h2>اخرین تصاویر ارسالی</h2>
    <?php
    $dir = 'panel/uploads/';
    if (is_dir($dir)) {
        echo '<div class="moh_avr">';
        $files = scandir($dir);
        rsort($files);
        $count = 0;
        foreach ($files as $file) {
            $file_ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if ($file_ext == "jpg") { // چک کردن پسوند فایل
                $count += 1;
                if ($count > 9) {
                    break;
                }
                ?>
                <div>
                    <a href="<?php echo $dir . $file; ?>">
                        <img src="<?php echo $dir . $file; ?>">
                    </a>
                </div>
                <?php
            }
        }
    }
    ?>
</center>
</body>
</html>
