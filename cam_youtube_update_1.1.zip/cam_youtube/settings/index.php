<?php
$servername = "localhost";
$dbname = "khaneho8_device_1";
$username = "khaneho8_device_1";
$password = "khaneho8_device_1";
$username_site = 'mohammad';

function getall($conn) {
    global $username_site;
    $sql = "SELECT wifi_user, wifi_pass, delay , stop_mode , push_mode , send_to_host , boudrate , save_Mode , send_bt , serial_code , stop_code , pause_code , save_G_c , save_delay , restor_code , restor_mode , light FROM settings WHERE username = '$username_site'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $result2 = array(1 => $row["delay"], 2 => $row["wifi_user"], 3 => $row["wifi_pass"], 4 => $row["stop_mode"], 5 => $row["push_mode"] , 6 => $row["send_to_host"] , 7 => $row["light"] , 8 => $row["boudrate"] , 9 => $row["save_Mode"] , 10 => $row["send_bt"] , 11 => $row["save_G_c"] , 12 => $row["save_delay"]  , 13 => $row["serial_code"] , 14 => $row["stop_code"] , 15 => $row["pause_code"]  , 16 => $row["restor_code"] , 17 => $row["restor_mode"] ,  18 => date('Y.m.d.H:i:s') );
        return json_encode($result2);
    } else {
        return json_encode(array('error' => 'اطلاعاتی پیدا نشد'));
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" href="Favicon.ico" type="image/x-icon">
    <title>تنظیمات</title>
    <style>
    
    @font-face{
    font-family:'Yekan';
    src:url('https://khane-hoshmand.ir/cam/Yekan.woff');
    font-weight:normal;
    font-style:normal;
}
html{
    font-family:Yekan,Arial;
    text-align:center;
}
body{
    max-width:600px;
    margin:0px auto;
    padding-top:100px;
}
.panel{
    background:#eee;
    border-radius:50px;
}
.switch{
    position:relative;
    display:inline-block;
    width:120px;
    height:63px;
}
.slider{
    border-radius:50px;
    position:absolute;
    cursor:pointer;
    top:0;
    bottom:0;
    left:0;
    right:0;
    background:#ccc;
    transition:0.5s;
}
.slider:before{
    border-radius:50px;
    position:absolute;
    content:"";
    height:55px;
    width:55px;
    left:4px;
    bottom:4px;
    background:white;
    transition:0.5s;
}
input:checked+.slider{
    background:#2196F3;
}
input:checked+.slider:before{
    transform:translateX(55px);
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            padding-right: 40px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius:12px;
        }
        input[type="checkbox"] {
            margin-bottom: 10px;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .notification {
            text-align: center;
            padding: 10px;
        }

    </style>
</head>
<body>
    <div class="container">
        <center><h2>تغییر تنظیمات</h2></center> 
        <?php
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("اتصال به دیتابیس ناموفق بود: " . $conn->connect_error);
        }

        $row = json_decode(getall($conn), true);

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $input_username = $_POST["username"];
            $input_password = $_POST["password"];
            $wifiUser = $_POST["wifiUser"];
            $wifiPass = $_POST["wifiPass"];
            $delay = $_POST["delay"];
            $boudrate = $_POST["boudrate"];
            $serial_code = $_POST["serial_code"];
            $pause_code = $_POST["pause_code"];
            $stop_code = $_POST["stop_code"];
            $restor_code = $_POST["restor_code"];
            $stopMode = isset($_POST["stopMode"]) ? 1 : 0;
            $pushMode = isset($_POST["pushMode"]) ? 1 : 0;
            $restor_mode = isset($_POST["restor_mode"]) ? 1 : 0;
            $send_to_host = isset($_POST["send_to_host"]) ? 1 : 0;          
            $light = isset($_POST["light"]) ? 1 : 0;          
            $save_Mode = isset($_POST["save_Mode"]) ? 1 : 0;            
            $send_bt = isset($_POST["send_bt"]) ? 1 : 0;           
            $save_G_c = isset($_POST["save_G_c"]) ? 1 : 0;        
            $save_delay = isset($_POST["save_delay"]) ? 1 : 0; 
            

            $sql = "SELECT * FROM settings WHERE username = '$input_username' AND password = '$input_password'";
            $result = $conn->query($sql);

            if ($result->num_rows == 1) {
                $updateSql = "UPDATE settings SET wifi_user = '$wifiUser', wifi_pass = '$wifiPass', delay = '$delay', stop_mode = '$stopMode', push_mode = '$pushMode' , send_to_host = '$send_to_host' , light = '$light' , boudrate = '$boudrate' , save_Mode = '$save_Mode' , send_bt = '$send_bt' ,  save_G_c = '$save_G_c' ,  save_delay = '$save_delay' ,  serial_code = '$serial_code' ,  stop_code = '$stop_code' ,  pause_code = '$pause_code' , restor_code = '$restor_code' , restor_mode = '$restor_mode' WHERE username = '$input_username'";
                if ($conn->query($updateSql) === TRUE) {
                    echo '<div class="notification">تنظیمات با موفقیت به‌روزرسانی شد.</div>';
                } else {
                    echo '<div class="notification">خطا در به‌روزرسانی تنظیمات: ' . $conn->error . '</div>';
                }
            } else {
                echo '<div class="notification">نام کاربری یا رمز عبور اشتباه است.</div>';
            }
        }
        $conn->close();
        ?>
        <form method="post">
          <label for="username">your username :</label>
            <input type="text" id="username" name="username" >
            
            <br>
            
            <label for="password">your password :</label>
            <input type="password" id="password" name="password" required value="">
            <br>
            
             <!-- <label for="wifiUser">Wi-Fi user:</label>
            <input type="text" id="wifiUser" name="wifiUser" required value="<?php echo $row[2]; ?>">
            <br>
            
            <label for="wifiPass">Wi-Fi pass :</label>
            <input type="password" id="wifiPass" name="wifiPass" required value="<?php echo $row[3]; ?>">
            <br>
            -->
            <label for="delay">picture send delay(seconds):</label>
            <input type="text" id="delay" name="delay" required value="<?php echo $row[1]; ?>">
            <br>
            
            <label for="boudrate">3d printer boudrate :</label>
            <input type="text" id="boudrate" name="boudrate" required value="<?php echo $row[8]; ?>">
            
            <br>
            
            <label for="serial_code">3d printer serial picture code :</label>
            <input type="text" id="serial_code" name="serial_code" required value="<?php echo $row[13]; ?>">
            
            <br>
            
            <label for="stop_code">3d printer stop code :</label>
            <input type="text" id="stop_code" name="stop_code" required value="<?php echo $row[14]; ?>">
            
            <br>
            
            <label for="pause_code">3d printer pause code :</label>
            <input type="text" id="pause_code" name="pause_code" required value="<?php echo $row[15]; ?>">
            
            <br>
            
            <label for="restor_code">3d printer restor print code :</label>
            <input type="text" id="restor_code" name="restor_code" required value="<?php echo $row[16]; ?>">
            
            <br>
            
            <label for="stopMode">stop print:</label>
            <input type="checkbox" id="stopMode" name="stopMode" <?php if ($row[4] == 1) echo 'checked'; ?>>
            
            <label for="pushMode">pause print:</label>
            <input type="checkbox" id="pushMode" name="pushMode" <?php if ($row[5] == 1) echo 'checked'; ?>>
            
             <label for="send_to_host">send photo to host:</label>
            <input type="checkbox" id="send_to_host" name="send_to_host" <?php if ($row[6] == 1) echo 'checked'; ?>>
            <br>
            
            <label for="light">light:</label>
            <input type="checkbox" id="light" name="light" <?php if ($row[7] == 1) echo 'checked'; ?>>
            
           <!-- 
           
           <label for="save_Mode"> save picture to sd card :</label>
            <input type="checkbox" id="save_Mode" name="save_Mode" <?php if ($row[9] == 1) echo 'checked'; ?>>
            
            <br>
            
            -->
            
            
            <label for="restor_mode">restor print :</label>
            <input type="checkbox" id="restor_mode" name="restor_mode" <?php if ($row[17] == 1) echo 'checked'; ?>>
            
            <br>
            
            <label for="send_bt">send picture with bottom :</label>
            <input type="checkbox" id="send_bt" name="send_bt" <?php if ($row[10] == 1) echo 'checked'; ?>>
            <br>
            
            <label for="save_G_c">send picture with G-code :</label>
            <input type="checkbox" id="save_G_c" name="save_G_c" <?php if ($row[11] == 1) echo 'checked'; ?>>
            <br>
            
            <label for="save_delay">send picture with delay time :</label>
            <input type="checkbox" id="save_delay" name="save_delay" <?php if ($row[12] == 1) echo 'checked'; ?>>
            
            <br><br>

            <input type="submit" value="ثبت تغییرات">
        </form>
    </div>
</body>
</html>
