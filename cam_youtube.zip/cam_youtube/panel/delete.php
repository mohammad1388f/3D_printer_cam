<?php
$correctPassword = '1234';
$requestData = json_decode(file_get_contents('php://input'), true);
$enteredPassword = $requestData['password']; // پسورد از درخواست POST
if ($enteredPassword !== $correctPassword) {
    http_response_code(403); // پاسخ ممنوع
    exit('Access Denied');
}

$directory = 'uploads';
$files = glob($directory . '/*.jpg');
foreach ($files as $file) {
    if (is_file($file)) {
        unlink($file);
    }
}
?>
