<?php
$servername = "localhost";
$dbname = "khaneho8_device_1";
$username = "khaneho8_device_1";
$password = "khaneho8_device_1";
$username_site = 'mohammad';

function getall($conn) {
    global $username_site;
    $sql = "SELECT wifi_user, wifi_pass, delay , stop_mode , push_mode , send_to_host , boudrate , save_Mode , send_bt , serial_code , stop_code , pause_code , save_G_c , save_delay , restor_code , restor_mode , light FROM settings WHERE username = '$username_site'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $result2 = array(1 => $row["delay"], 2 => $row["wifi_user"], 3 => $row["wifi_pass"], 4 => $row["stop_mode"], 5 => $row["push_mode"] , 6 => $row["send_to_host"] , 7 => $row["light"] , 8 => $row["boudrate"] , 9 => $row["save_Mode"] , 10 => $row["send_bt"] , 11 => $row["save_G_c"] , 12 => $row["save_delay"]  , 13 => $row["serial_code"] , 14 => $row["stop_code"] , 15 => $row["pause_code"]  , 16 => $row["restor_code"] , 17 => $row["restor_mode"] ,  18 => date('Y.m.d.H:i:s') );
        return json_encode($result2);
    } else {
        return json_encode(array('error' => 'اطلاعاتی پیدا نشد'));
    }
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $action = $_GET["action"];
    if ($action == "update_values") {
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("اتصال به دیتابیس ناموفق بود: " . $conn->connect_error);
        }

        $result = getall($conn);

        if ($result !== false) {
            echo $result;
        }

        $conn->close();
    }
}
?>